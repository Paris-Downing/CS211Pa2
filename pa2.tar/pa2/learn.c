//Paris Downing
//October 15, 2017
//Comp Arc Project 2

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

//transposes the original matrix
void transpose(double **matrix, double **newMatrix, int rows, int cols)
{
	int i;
	int j;
	for(i = 0; i < rows; i++)
		for(j = 0; j < cols + 1; j++)
			newMatrix[j][i] = matrix[i][j];
}
//creates a rows x rows matrix that has 1s on the diagonal and 0 everywhere else
void augmented(double ** newMatrix, int rows)
{
        int i;
        int j;
        for(i = 0; i < rows; i++)
                for(j = 0; j < rows; j++)
                        if(i == j)
                                newMatrix[i][j] = 1;
}
//multiplies two matrices by each other, should hopefully not receive two matries that can't be multiplied
void multiply(double **matrix1, double **matrix2, double **newMatrix, int row1, int col1, int col2)
{
       int i, j, k;
       double sum = 0;
       for(i = 0; i < row1; i++)
               for(j = 0; j < col2; j++)
                {
                       for(k = 0; k < col1; k++)
                               sum += matrix1[i][k] * matrix2[k][j];
                       newMatrix[i][j] = sum;
                       sum = 0;
                }
}
//creates a duplicate matrix so the original data doesn't get destroyed
void copyInto(double **matrix1, double **matrix2, int rows, int cols)
{	
	int i;
	int j;
	for(i = 0; i < rows; i++)
		for(j = 0; j < cols; j++)
			matrix2[i][j] = matrix1[i][j];
}
//subtracts a row in a matrix by another row times a constant to get the non-diagonal equal to 0
void subtractRow(double **matrix1, int col, int row1, int row2, double c)
{
	int i;
        for(i = 0; i < col; i++)
                matrix1[row1][i] = matrix1[row1][i] - (c * matrix1[row2][i]);
}
//divides row by a constant to get the diagonal equal to 1
void divideRow(double **matrix1, int col, int target, double constant)
{
	int i;
	for(i = 0; i < col; i++)
		matrix1[target][i] = matrix1[target][i] / constant;
}
//sets negative zeros to zero to avoid confusion
void setZero(double **matrix, int rows, int cols)
{
	int i;
	int j;
	for(i = 0; i < rows; i++)
		for(j = 0; j < cols; j++)
			if(matrix[i][j] == 0)
				matrix[i][j] = 0;
}
//inverts a matrix 
void invert(double **aug, double **newMatrix, int rows, int cols)
{
	int i;
	int j;
	for(i = 0; i < rows; i++)
	{
		for(j = 0; j <= i; j++)
		{
			//sets diagonal to 1
			if(i == j)
			{
				double c = newMatrix[i][j];
				divideRow(newMatrix, cols, i, c);
				divideRow(aug, cols, i, c);
			}
			//sets numbers below the diagonal to 0
			else
			{
				if(newMatrix[i][j] != 0)
				{
					double c = newMatrix[i][j]/newMatrix[j][j];
					subtractRow(newMatrix, cols, i, j, c);
					subtractRow(aug, cols, i, j, c);
				}
			}
		}
	}
	//sets negative 0s to positive 0s
	setZero(newMatrix, rows, cols);
	setZero(aug, rows, cols);
	//set the numbers above the diagonal to 0
	for(i = 0; i < rows; i++)
	{
		for(j = i; j < cols; j++)
		{
			if(i != j)
			{
				double c = newMatrix[i][j]/newMatrix[j][j];
				subtractRow(newMatrix, cols, i, j, c);
				subtractRow(aug, cols, i, j, c);
			}
		}
	}
	//set the numbers above the diagonal to 0
	setZero(newMatrix, rows, cols);
	setZero(aug, rows, cols);
}
//calculates the weights matrix
void output(double ** arrayX, double **arrayY, double ** arrayW, int houses, int attributes)
{
		int i;
		double **augMatrix = (double **)malloc(sizeof(double *)* houses);
		double **transMatrix = (double **)malloc(sizeof(double *)* (attributes + 1));
		double **multiplyMatrix = (double **)malloc(sizeof(double *)* (attributes + 1));
		double **copyMatrix = (double **)malloc(sizeof(double *)* houses);
		double **intra = (double **)malloc(sizeof(double *)* (attributes + 1));
		double **testing = (double **)malloc(sizeof(double *)* houses);
		for(i = 0; i < houses; i++)
		{
			augMatrix[i] = (double *)malloc(sizeof(double) * (attributes + 1));
			copyMatrix[i] = (double *)malloc(sizeof(double) * (attributes + 1));
			testing[i] = (double *)malloc(sizeof(double) * 1);
		}
		for(i = 0; i < attributes + 1; i++)
		{
			transMatrix[i] = (double *)malloc(sizeof(double) * houses);
			multiplyMatrix[i] = (double *)malloc(sizeof(double) * (attributes + 1));
			intra[i] = (double *)malloc(sizeof(double) * (houses));
		}
		transpose(arrayX, transMatrix, houses, attributes);
		augmented(augMatrix, attributes + 1);
		multiply(transMatrix, arrayX, multiplyMatrix, attributes + 1, houses, attributes + 1);
		copyInto(arrayX, copyMatrix, houses, attributes + 1);
		invert(augMatrix, multiplyMatrix, attributes + 1, attributes + 1);
		multiply(augMatrix, transMatrix, intra, attributes + 1, attributes + 1, houses);
		multiply(intra, arrayY, arrayW, attributes + 1, houses, 1);
		multiply(arrayX, arrayW, testing, houses, attributes + 1, 1);
}
//scans in matrices and calculates the final prices
int main(int argc, char *argv[])
{
        if(argc <= 1)
	{
		printf("You did not feed me arguments\n");
		exit(1);
		return 0;
	}
	FILE *pointer = fopen(argv[1], "r");
	//checks to make sure file exists
	if(pointer == NULL)
	{
		printf("error\n");
		exit(1);
		return 0;
	}
	else
	{
		int attributes;
                int houses;
		fscanf(pointer, "%d", &attributes);
		fscanf(pointer, "%d", &houses);
		//creates arrays and allocates size
		double **arrayX = (double **)malloc(sizeof(double *)* houses);
		double **arrayY = (double **)malloc(sizeof(double *)* houses);
		double **arrayW = (double **)malloc(sizeof(double*)* (attributes + 1));
		int i;
		for(i = 0; i < houses; i++)
		{
			arrayX[i] = (double *)malloc(sizeof(double) * (attributes + 1));
			arrayY[i] = (double *)malloc(sizeof(double) * 1);
		}
		for(i = 0; i < attributes + 1; i++)
			arrayW[i] = (double *)malloc(sizeof(double) * 1);
		double input;
		int counter = 0;
		int line = 0;
		//reads in data from first file
		while(fscanf(pointer, "%lf", &input) != EOF)
		{
			if(counter == 0)
                        {      	
				arrayX[line][0] = 1;
				arrayX[line][1] = input;
                                fscanf(pointer, ",");
                                counter++;
                        }
                        else if(counter == attributes)
                        {      
			       arrayY[line][0] = input;
                               counter = 0;
                               line++;
                        }
                        else
                       {   
			       arrayX[line][counter + 1] = input;   
                               fscanf(pointer, ",");
                               counter++;
                       }
		}
		//calculates weights
		output(arrayX, arrayY, arrayW, houses, attributes);
		//prepares for second file
		fclose(pointer);
		FILE *pointer2 = fopen(argv[2], "r");
		if(pointer2 == NULL)
		{
			printf("error\n");
			exit(1);
			return 0;
		}
		else
		{
			int size;
			int i;
			line = 0;
			counter = 0;
			double scanIn;
			fscanf(pointer2, "%d", &size);
			double **prices = (double **)malloc(sizeof(double *)* size);
			for(i = 0; i < size; i++)
				prices[i] = (double *)malloc(sizeof(double) * (attributes));
			while(fscanf(pointer2, "%lf", &scanIn) != EOF)
			{
				prices[line][counter] = scanIn;
				//if last in line
                       		if(counter + 1== attributes)
                        	{      
					fscanf(pointer2, "\n");
					counter = 0;
                               		line++;
                        	}
				//if first in line
				else if(counter == 0)
                        	{      	
					fscanf(pointer2, ",");
                                	counter++;
                        	}
                        	else
                       		{   
                               		fscanf(pointer2, ",");
                               		counter++;
                       		}
				
			}
			fclose(pointer2);
			//calculates prices using the weights and the second file
			int j;
			double ** finalValues = (double**)malloc(sizeof(double*) * size);
			for(i = 0; i < size; i++)
				finalValues[i] = (double *)malloc(sizeof(double) * 1);
			int isFirst = 0;
			double sum = 0;
			for(i = 0; i < size; i++)
			{
				for(j = 0; j <= attributes; j++)
				{
					if(isFirst == 0)
					{
						sum = arrayW[0][0];
						isFirst = 1;
					}
					else 
						sum += arrayW[j][0] * prices[i][j - 1];
				}
				finalValues[i][0] = sum;
				sum = 0;
				isFirst = 0;
			}	
			for(i = 0; i < size; i++)
				printf("%0.0lf\n", finalValues[i][0]);
		}
	}
	return 0;
}
